package com.subscriptionbilling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SubscriptionbillingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SubscriptionbillingApplication.class, args);
	}

}
